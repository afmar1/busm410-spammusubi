# Repository guidance

This repository contains a BUSM 410 analysis of the public Iowa Liquor Sales dataset.

## Working conventions

- Treat `bigquery-public-data.iowa_liquor_sales.sales` as the source table unless the project documentation says otherwise.
- Use GoogleSQL and fully qualify public table names.
- Keep each analysis query focused on one business question and add a short header comment describing its output.
- State the row grain before adding joins or aggregations.
- Do not commit credentials, raw data extracts, or generated BigQuery result files.
- Do not present an observation as a finding until its SQL, date range, and filters are documented.
- Save presentation-ready charts in `visuals/` and explain what each chart shows in `visuals/README.md`.

## Before submitting changes

Review the project with `.agents/skills/project-audit/SKILL.md`. Confirm that the README, charter, model, SQL, findings, and visuals agree with one another.
