# Data Model

## Source grain

The source table contains one row per invoice line item. `invoice_and_item_number` is the closest available transaction-line identifier and should be checked for uniqueness within the selected analysis period.

## Analytical model

For this project, the public table can be treated as a denormalized fact table.

### Measures

- `sale_dollars`
- `bottles_sold`
- `volume_sold_liters`
- `volume_sold_gallons`

### Time attributes

- `date`
- Derived year, quarter, month, and month start

### Store and geography attributes

- `store_number`, `store_name`
- `city`, `zip_code`, `county`
- `store_location`

### Product attributes

- `item_number`, `item_description`
- `category`, `category_name`
- `vendor_number`, `vendor_name`
- `pack`, `bottle_volume_ml`

## Modeling rules

- Aggregate additive measures with `SUM`.
- Use stable numeric identifiers for grouping when possible; display names may change or contain variants.
- Apply the same date and data-quality filters across comparison queries.
- Do not sum cost or retail price fields; calculate weighted values from transaction quantities when needed.
- Document any deduplication before publishing results.
