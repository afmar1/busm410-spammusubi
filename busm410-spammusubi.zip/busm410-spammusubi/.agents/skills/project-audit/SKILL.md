---
name: project-audit
description: Audit the SpamMusubi Iowa Liquor Sales project for internal consistency, reproducibility, evidence quality, and submission readiness. Use when reviewing the project or preparing it for submission; do not use to invent findings or broaden the analysis scope.
---

# Project Audit

Review the repository as an analysis deliverable. Report concrete issues with file paths and prioritize corrections that affect accuracy or reproducibility.

## Audit checks

1. Read `README.md` and `charter.md` to identify the stated audience, scope, and questions.
2. Confirm `model/README.md` defines the source grain, measures, dimensions, and aggregation rules used by the SQL.
3. Review every query in `sql/` for a fully qualified source table, consistent date range, null handling, safe arithmetic, and a stated output purpose.
4. Trace every numeric claim in `findings.md` to a query. Flag unsupported, causal, or profit-related language.
5. Confirm every final chart in `visuals/` documents its source query, filters, units, and takeaway.
6. Check that public documentation contains no credentials, raw data extracts, or personal information.

## Output

Organize the audit as:

- **Ready:** elements that are complete and consistent
- **Fix before submission:** accuracy, evidence, or reproducibility problems
- **Polish:** presentation improvements that do not change the analysis

Do not edit files unless the user asks for corrections. Do not fabricate results to complete placeholders.
