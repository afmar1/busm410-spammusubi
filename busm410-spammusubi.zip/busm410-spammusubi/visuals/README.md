# Visuals

Store presentation-ready chart exports in this folder.

For each visual, document:

- File name and chart title
- Business question answered
- Date range and filters
- Query used to create it
- One-sentence takeaway

## Planned visuals

1. Monthly sales and volume trend — `sql/01_sales_overview.sql`
2. Top product categories by sales — `sql/02_top_products.sql`
3. County sales versus volume — `sql/03_county_trends.sql`

Use clear units, sort rankings intentionally, and avoid 3D effects. Do not export charts containing credentials or personal data.
