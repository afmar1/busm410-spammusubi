# SpamMusubi — Iowa Liquor Sales Analysis

SpamMusubi is a BUSM 410 analytics project exploring Iowa's public liquor sales data. The project is organized so that the business question, SQL, data model, visuals, and findings can be reviewed independently.

## Team

- **Team name:** SpamMusubi
- **Members:** Algie and Sia

## Project question

How do liquor sales vary by product, location, and time, and which patterns could help a retailer make better assortment and inventory decisions?

## Data source

- **Dataset:** Iowa Liquor Sales
- **BigQuery table:** `bigquery-public-data.iowa_liquor_sales.sales`
- **Google Cloud project:** `salesproject-511800`
- **Unit of analysis:** One invoice line item

## Repository guide

| Path | Purpose |
| --- | --- |
| [`charter.md`](charter.md) | Scope, audience, questions, and deliverables |
| [`findings.md`](findings.md) | Evidence-backed findings and recommendations |
| [`sql/`](sql/) | Reproducible BigQuery analysis queries |
| [`model/`](model/) | Grain, measures, dimensions, and modeling decisions |
| [`visuals/`](visuals/) | Exported charts and dashboard documentation |
| [`Other/`](Other/) | Working notes and supporting material |
| [`.agents/skills/project-audit/`](.agents/skills/project-audit/) | A repeatable project-review checklist |

## Quick start

1. Open the project in BigQuery using project ID `salesproject-511800`.
2. Run the numbered queries in [`sql/`](sql/) from lowest to highest.
3. Record verified results in [`findings.md`](findings.md).
4. Add final chart exports and captions to [`visuals/`](visuals/).

All SQL uses GoogleSQL. Results and visuals should state the date range and any filters used so the analysis remains reproducible.
