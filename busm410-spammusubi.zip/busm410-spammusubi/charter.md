# Project Charter

## Purpose

Analyze Iowa liquor sales to identify useful patterns in product performance, geographic demand, and seasonality. The final work should help a retail decision-maker understand where sales come from and where assortment or inventory decisions may need attention.

## Audience

- BUSM 410 instructor and classmates
- Retail managers responsible for assortment and inventory
- Analysts who need to reproduce or extend the work

## Questions

1. How do sales dollars and liters sold change over time?
2. Which products and categories contribute the most sales?
3. Which counties and stores account for the largest share of sales?
4. Are there meaningful seasonal or geographic differences in demand?
5. What practical inventory or assortment actions are supported by the evidence?

## Scope

### Included

- Sales recorded in the Iowa Liquor Sales public dataset
- Product, store, county, and time-based analysis
- Sales dollars, bottles sold, and volume sold
- Reproducible BigQuery SQL and presentation-ready visuals

### Excluded

- Consumer demographics or individual purchasing behavior
- Profit analysis without independently verified margin data
- Causal claims about why a sales pattern occurred
- Forecasts unless assumptions and evaluation methods are documented

## Deliverables

- Documented data model
- Reproducible SQL queries
- A concise set of charts
- Evidence-backed findings and recommendations

## Definition of done

The project is ready for submission when every reported number can be traced to a query, every chart includes a clear title and units, limitations are stated, and recommendations follow directly from verified findings.
