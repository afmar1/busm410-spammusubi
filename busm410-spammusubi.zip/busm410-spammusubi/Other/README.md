# Supporting Material

Use this folder for working notes, data-quality observations, meeting notes, and supporting documents that do not belong in the final model, SQL, findings, or visuals folders.

Keep final conclusions in `findings.md` so reviewers have one authoritative summary.
