# Working Notes

## Decisions

- Source table: `bigquery-public-data.iowa_liquor_sales.sales`
- Query dialect: GoogleSQL
- Primary measures: sales dollars, bottles sold, and volume sold in liters

## Open questions

- What analysis period will be used for the final presentation?
- Should rankings focus on categories, individual products, or both?
- Will the project compare total county sales only, or add population data for per-capita context?

## Data-quality checks

- Check for null or blank county, category, and item descriptions.
- Confirm that date filters are identical across all reported metrics.
- Check for zero or negative values before calculating averages or unit prices.
