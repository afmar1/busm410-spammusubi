-- Compares county sales, volume, and active-store counts.
-- Totals are not population-adjusted.

SELECT
  COALESCE(NULLIF(TRIM(county), ''), 'Unknown') AS county,
  ROUND(SUM(sale_dollars), 2) AS sales_dollars,
  SUM(bottles_sold) AS bottles_sold,
  ROUND(SUM(volume_sold_liters), 2) AS volume_sold_liters,
  COUNT(DISTINCT store_number) AS active_stores,
  ROUND(
    SAFE_DIVIDE(SUM(sale_dollars), COUNT(DISTINCT store_number)),
    2
  ) AS sales_per_active_store
FROM `bigquery-public-data.iowa_liquor_sales.sales`
WHERE date >= DATE('2023-01-01')
  AND date < DATE('2024-01-01')
  AND sale_dollars IS NOT NULL
GROUP BY county
ORDER BY sales_dollars DESC;
