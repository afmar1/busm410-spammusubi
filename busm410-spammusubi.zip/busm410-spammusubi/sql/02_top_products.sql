-- Ranks product categories by sales and calculates each category's share.

WITH category_sales AS (
  SELECT
    COALESCE(CAST(category AS STRING), 'Unknown') AS category_id,
    COALESCE(NULLIF(TRIM(category_name), ''), 'Unknown') AS category_name,
    SUM(sale_dollars) AS sales_dollars,
    SUM(bottles_sold) AS bottles_sold,
    SUM(volume_sold_liters) AS volume_sold_liters
  FROM `bigquery-public-data.iowa_liquor_sales.sales`
  WHERE date >= DATE('2023-01-01')
    AND date < DATE('2024-01-01')
    AND sale_dollars IS NOT NULL
  GROUP BY category_id, category_name
)
SELECT
  category_id,
  category_name,
  ROUND(sales_dollars, 2) AS sales_dollars,
  bottles_sold,
  ROUND(volume_sold_liters, 2) AS volume_sold_liters,
  ROUND(100 * SAFE_DIVIDE(sales_dollars, SUM(sales_dollars) OVER ()), 2)
    AS share_of_sales_pct
FROM category_sales
ORDER BY sales_dollars DESC
LIMIT 20;
