# SQL Analysis

Run these GoogleSQL queries in order:

1. `01_sales_overview.sql` — monthly sales, volume, and transaction-line activity
2. `02_top_products.sql` — leading categories and their share of sales
3. `03_county_trends.sql` — county-level sales and volume comparisons

Before final submission, set a shared analysis period and use it consistently in all queries and visuals.
