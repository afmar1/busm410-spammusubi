-- Monthly overview of sales dollars, bottles, volume, and invoice lines.
-- Adjust the dates below, then use the same period in every project query.

SELECT
  DATE_TRUNC(date, MONTH) AS month,
  ROUND(SUM(sale_dollars), 2) AS sales_dollars,
  SUM(bottles_sold) AS bottles_sold,
  ROUND(SUM(volume_sold_liters), 2) AS volume_sold_liters,
  COUNT(*) AS invoice_lines,
  COUNT(DISTINCT store_number) AS active_stores
FROM `bigquery-public-data.iowa_liquor_sales.sales`
WHERE date >= DATE('2023-01-01')
  AND date < DATE('2024-01-01')
  AND sale_dollars IS NOT NULL
GROUP BY month
ORDER BY month;
